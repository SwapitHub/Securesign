"use client";

export const NewMultisig = () => {
  return (
   <>fffff</>
  );
};
