import React from 'react'

export const MultisigAccounts = () => {
  return (
    <div>MultisigAccounts</div>
  )
}
