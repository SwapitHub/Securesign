import React from 'react'

export const AddressBook = () => {
  return (
    <div>AddressBook</div>
  )
}
