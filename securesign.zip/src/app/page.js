import { Dashboard } from "./component/Dashboard";

export default function Home() {
  return (
   <>
   <Dashboard/>
   </>
  );
}
